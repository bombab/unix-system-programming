#ifndef _SHDMEMORY_H
#define _SHDMEMORY_H
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <signal.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>

#define C1toS_SHKEY (key_t)60144 // client1->sever 작업 큐의 key 값
#define C2toS_SHKEY (key_t)60145 // client2->server 작업 큐의  key 값
#define StoC1_SHKEY (key_t)60146 // server->cleint1 작업 큐의 key 값
#define StoC2_SHKEY (key_t)60147 // server->cleint2 작업 큐의 key  값
#define SEM_KEY (key_t)60148
#define MAX_SIZE 100
#define IFLAGS (IPC_CREAT | IPC_EXCL)
#define ERR -1
static int semid;
static int C1toSid;
static int C2toSid;
static int StoC1id;
static int StoC2id;

typedef union _semun
{
    int val;
    struct semid_ds *buf;
    ushort *array;
} semun;

typedef struct
{
    //  Client가 Server에게 전달( 공유)할 메시지 타입
    int normal_result;
    int order_result;
    int inverse_result;
    char cal_formula[MAX_SIZE];
    int is_all_shared;
} c2s_msg;

typedef struct
{ // Server가 Client에게 전달(공유)할 메시지 타입
    char print_msg[MAX_SIZE * 2];
    int is_all_shared;
} s2c_msg;

c2s_msg *CreateC2SMemory(key_t type)
{ // client에서 server로 공유할 공유메모리 생성

    int shmid;
    c2s_msg *shm_ptr;
    if ((shmid = shmget(type, sizeof(c2s_msg), 0600 | IFLAGS)) == -1)
        exit(1);

    if ((shm_ptr = (c2s_msg *)shmat(shmid, 0, 0)) == (c2s_msg *)ERR)
        exit(1);

    if(type == C1toS_SHKEY) C1toSid = shmid;
    else C2toSid = shmid;

    return shm_ptr;
}

s2c_msg *CreateS2CMemory(key_t type)
{ // client에서 server로 공유할 공유메모리 생성

    int shmid;
    s2c_msg *shm_ptr;
    if ((shmid = shmget(type, sizeof(s2c_msg), 0600 | IFLAGS)) == -1)
        exit(1);

    if ((shm_ptr = (s2c_msg *)shmat(shmid, 0, 0)) == (s2c_msg *)ERR)
        exit(1);

    if(type == StoC1_SHKEY) StoC1id = shmid;
    else StoC2id = shmid;

    return shm_ptr;
}
#endif

int getsem(void)
{ /* 세마포어 집합을 얻는다.*/
    semun x;
    x.val = 1;

    /* 두 개의 세마포어를 갖는 집합을 생성한다. */
    if ((semid = semget(SEM_KEY, 2, 0600 | IFLAGS)) == -1)
        exit(1);
    /* 초기값을 지정한다.*/
    if (semctl(semid, 0, SETVAL, x) == -1)
        exit(1);
    if (semctl(semid, 1, SETVAL, x) == -1)
        exit(1);
    return (semid);
}